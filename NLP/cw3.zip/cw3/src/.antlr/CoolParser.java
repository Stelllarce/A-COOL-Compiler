// Generated from /home/student/my-code/cw3/src/CoolParser.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast", "CheckReturnValue"})
public class CoolParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.13.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		SEMI=1, OCURLY=2, CCURLY=3, OPAREN=4, COMMA=5, CPAREN=6, COLON=7, AT=8, 
		DOT=9, PLUS=10, MINUS=11, STAR=12, SLASH=13, TILDE=14, LT=15, EQ=16, DARROW=17, 
		ASSIGN=18, LE=19, CLASS=20, ELSE=21, FI=22, IF=23, IN=24, INHERITS=25, 
		ISVOID=26, LET=27, LOOP=28, POOL=29, THEN=30, WHILE=31, CASE=32, ESAC=33, 
		NEW=34, OF=35, NOT=36, BOOL_CONST=37, INT_CONST=38, OBJECTID=39, TYPEID=40, 
		WS=41, STR_BEGIN=42, COMM_BEGIN=43, COMM_ERR1=44, LCOMM_BEGIN=45, ERROR=46, 
		STR_CONST=47, STR_END=48, STR_ESC_NL=49, ESC_BS=50, ESC_FF=51, ESC_TAB=52, 
		ESC_NULL=53, ESC_ANY=54, NULL=55, STR_NL=56, STR_ERR=57, STR_ANY=58, ESTR_END=59, 
		ESTR_ESC_NL=60, ESTR_NL=61, ESTR_ANY=62, OCOMM=63, CCOMM=64, COMM_SKIP=65, 
		COMM_ERR=66, LCOMM_END=67, LCOMM_SKIP=68;
	public static final int
		RULE_program = 0, RULE_class = 1, RULE_method = 2, RULE_attr = 3, RULE_formal = 4, 
		RULE_expr = 5, RULE_vardecl = 6;
	private static String[] makeRuleNames() {
		return new String[] {
			"program", "class", "method", "attr", "formal", "expr", "vardecl"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "';'", "'{'", "'}'", "'('", "','", "')'", "':'", "'@'", "'.'", 
			"'+'", "'-'", "'*'", "'/'", "'~'", "'<'", "'='", "'=>'", "'<-'", "'<='", 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, null, null, null, null, null, null, null, null, null, null, null, 
			null, "'--'", null, "'?'", null, null, null, null, null, null, null, 
			null, null, null, null, null, "'\\n'", null, null, null, null, null, 
			null, "'\\n'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, "SEMI", "OCURLY", "CCURLY", "OPAREN", "COMMA", "CPAREN", "COLON", 
			"AT", "DOT", "PLUS", "MINUS", "STAR", "SLASH", "TILDE", "LT", "EQ", "DARROW", 
			"ASSIGN", "LE", "CLASS", "ELSE", "FI", "IF", "IN", "INHERITS", "ISVOID", 
			"LET", "LOOP", "POOL", "THEN", "WHILE", "CASE", "ESAC", "NEW", "OF", 
			"NOT", "BOOL_CONST", "INT_CONST", "OBJECTID", "TYPEID", "WS", "STR_BEGIN", 
			"COMM_BEGIN", "COMM_ERR1", "LCOMM_BEGIN", "ERROR", "STR_CONST", "STR_END", 
			"STR_ESC_NL", "ESC_BS", "ESC_FF", "ESC_TAB", "ESC_NULL", "ESC_ANY", "NULL", 
			"STR_NL", "STR_ERR", "STR_ANY", "ESTR_END", "ESTR_ESC_NL", "ESTR_NL", 
			"ESTR_ANY", "OCOMM", "CCOMM", "COMM_SKIP", "COMM_ERR", "LCOMM_END", "LCOMM_SKIP"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "CoolParser.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public CoolParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ProgramContext extends ParserRuleContext {
		public List<ClassContext> class_() {
			return getRuleContexts(ClassContext.class);
		}
		public ClassContext class_(int i) {
			return getRuleContext(ClassContext.class,i);
		}
		public List<TerminalNode> SEMI() { return getTokens(CoolParser.SEMI); }
		public TerminalNode SEMI(int i) {
			return getToken(CoolParser.SEMI, i);
		}
		public ProgramContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_program; }
	}

	public final ProgramContext program() throws RecognitionException {
		ProgramContext _localctx = new ProgramContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_program);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(17); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(14);
				class_();
				setState(15);
				match(SEMI);
				}
				}
				setState(19); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( _la==CLASS );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ClassContext extends ParserRuleContext {
		public TerminalNode CLASS() { return getToken(CoolParser.CLASS, 0); }
		public List<TerminalNode> TYPEID() { return getTokens(CoolParser.TYPEID); }
		public TerminalNode TYPEID(int i) {
			return getToken(CoolParser.TYPEID, i);
		}
		public TerminalNode OCURLY() { return getToken(CoolParser.OCURLY, 0); }
		public TerminalNode CCURLY() { return getToken(CoolParser.CCURLY, 0); }
		public TerminalNode INHERITS() { return getToken(CoolParser.INHERITS, 0); }
		public List<TerminalNode> SEMI() { return getTokens(CoolParser.SEMI); }
		public TerminalNode SEMI(int i) {
			return getToken(CoolParser.SEMI, i);
		}
		public List<MethodContext> method() {
			return getRuleContexts(MethodContext.class);
		}
		public MethodContext method(int i) {
			return getRuleContext(MethodContext.class,i);
		}
		public List<AttrContext> attr() {
			return getRuleContexts(AttrContext.class);
		}
		public AttrContext attr(int i) {
			return getRuleContext(AttrContext.class,i);
		}
		public ClassContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_class; }
	}

	public final ClassContext class_() throws RecognitionException {
		ClassContext _localctx = new ClassContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_class);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(21);
			match(CLASS);
			setState(22);
			match(TYPEID);
			setState(25);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==INHERITS) {
				{
				setState(23);
				match(INHERITS);
				setState(24);
				match(TYPEID);
				}
			}

			setState(27);
			match(OCURLY);
			setState(36);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==OBJECTID) {
				{
				{
				setState(30);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,2,_ctx) ) {
				case 1:
					{
					setState(28);
					method();
					}
					break;
				case 2:
					{
					setState(29);
					attr();
					}
					break;
				}
				setState(32);
				match(SEMI);
				}
				}
				setState(38);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(39);
			match(CCURLY);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class MethodContext extends ParserRuleContext {
		public TerminalNode OBJECTID() { return getToken(CoolParser.OBJECTID, 0); }
		public TerminalNode OPAREN() { return getToken(CoolParser.OPAREN, 0); }
		public TerminalNode CPAREN() { return getToken(CoolParser.CPAREN, 0); }
		public TerminalNode COLON() { return getToken(CoolParser.COLON, 0); }
		public TerminalNode TYPEID() { return getToken(CoolParser.TYPEID, 0); }
		public TerminalNode OCURLY() { return getToken(CoolParser.OCURLY, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public TerminalNode CCURLY() { return getToken(CoolParser.CCURLY, 0); }
		public List<FormalContext> formal() {
			return getRuleContexts(FormalContext.class);
		}
		public FormalContext formal(int i) {
			return getRuleContext(FormalContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(CoolParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(CoolParser.COMMA, i);
		}
		public MethodContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_method; }
	}

	public final MethodContext method() throws RecognitionException {
		MethodContext _localctx = new MethodContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_method);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(41);
			match(OBJECTID);
			setState(42);
			match(OPAREN);
			setState(51);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==OBJECTID) {
				{
				setState(43);
				formal();
				setState(48);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(44);
					match(COMMA);
					setState(45);
					formal();
					}
					}
					setState(50);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				}
			}

			setState(53);
			match(CPAREN);
			setState(54);
			match(COLON);
			setState(55);
			match(TYPEID);
			setState(56);
			match(OCURLY);
			setState(57);
			expr(0);
			setState(58);
			match(CCURLY);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class AttrContext extends ParserRuleContext {
		public TerminalNode OBJECTID() { return getToken(CoolParser.OBJECTID, 0); }
		public TerminalNode COLON() { return getToken(CoolParser.COLON, 0); }
		public TerminalNode TYPEID() { return getToken(CoolParser.TYPEID, 0); }
		public TerminalNode ASSIGN() { return getToken(CoolParser.ASSIGN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public AttrContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_attr; }
	}

	public final AttrContext attr() throws RecognitionException {
		AttrContext _localctx = new AttrContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_attr);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(60);
			match(OBJECTID);
			setState(61);
			match(COLON);
			setState(62);
			match(TYPEID);
			setState(65);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ASSIGN) {
				{
				setState(63);
				match(ASSIGN);
				setState(64);
				expr(0);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class FormalContext extends ParserRuleContext {
		public TerminalNode OBJECTID() { return getToken(CoolParser.OBJECTID, 0); }
		public TerminalNode COLON() { return getToken(CoolParser.COLON, 0); }
		public TerminalNode TYPEID() { return getToken(CoolParser.TYPEID, 0); }
		public FormalContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_formal; }
	}

	public final FormalContext formal() throws RecognitionException {
		FormalContext _localctx = new FormalContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_formal);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(67);
			match(OBJECTID);
			setState(68);
			match(COLON);
			setState(69);
			match(TYPEID);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class ExprContext extends ParserRuleContext {
		public List<TerminalNode> OBJECTID() { return getTokens(CoolParser.OBJECTID); }
		public TerminalNode OBJECTID(int i) {
			return getToken(CoolParser.OBJECTID, i);
		}
		public TerminalNode OPAREN() { return getToken(CoolParser.OPAREN, 0); }
		public TerminalNode CPAREN() { return getToken(CoolParser.CPAREN, 0); }
		public List<ExprContext> expr() {
			return getRuleContexts(ExprContext.class);
		}
		public ExprContext expr(int i) {
			return getRuleContext(ExprContext.class,i);
		}
		public List<TerminalNode> COMMA() { return getTokens(CoolParser.COMMA); }
		public TerminalNode COMMA(int i) {
			return getToken(CoolParser.COMMA, i);
		}
		public TerminalNode IF() { return getToken(CoolParser.IF, 0); }
		public TerminalNode THEN() { return getToken(CoolParser.THEN, 0); }
		public TerminalNode ELSE() { return getToken(CoolParser.ELSE, 0); }
		public TerminalNode FI() { return getToken(CoolParser.FI, 0); }
		public TerminalNode WHILE() { return getToken(CoolParser.WHILE, 0); }
		public TerminalNode LOOP() { return getToken(CoolParser.LOOP, 0); }
		public TerminalNode POOL() { return getToken(CoolParser.POOL, 0); }
		public TerminalNode OCURLY() { return getToken(CoolParser.OCURLY, 0); }
		public TerminalNode CCURLY() { return getToken(CoolParser.CCURLY, 0); }
		public List<TerminalNode> SEMI() { return getTokens(CoolParser.SEMI); }
		public TerminalNode SEMI(int i) {
			return getToken(CoolParser.SEMI, i);
		}
		public TerminalNode CASE() { return getToken(CoolParser.CASE, 0); }
		public TerminalNode OF() { return getToken(CoolParser.OF, 0); }
		public TerminalNode ESAC() { return getToken(CoolParser.ESAC, 0); }
		public List<TerminalNode> COLON() { return getTokens(CoolParser.COLON); }
		public TerminalNode COLON(int i) {
			return getToken(CoolParser.COLON, i);
		}
		public List<TerminalNode> TYPEID() { return getTokens(CoolParser.TYPEID); }
		public TerminalNode TYPEID(int i) {
			return getToken(CoolParser.TYPEID, i);
		}
		public List<TerminalNode> DARROW() { return getTokens(CoolParser.DARROW); }
		public TerminalNode DARROW(int i) {
			return getToken(CoolParser.DARROW, i);
		}
		public TerminalNode NEW() { return getToken(CoolParser.NEW, 0); }
		public TerminalNode TILDE() { return getToken(CoolParser.TILDE, 0); }
		public TerminalNode ISVOID() { return getToken(CoolParser.ISVOID, 0); }
		public TerminalNode NOT() { return getToken(CoolParser.NOT, 0); }
		public TerminalNode ASSIGN() { return getToken(CoolParser.ASSIGN, 0); }
		public TerminalNode LET() { return getToken(CoolParser.LET, 0); }
		public List<VardeclContext> vardecl() {
			return getRuleContexts(VardeclContext.class);
		}
		public VardeclContext vardecl(int i) {
			return getRuleContext(VardeclContext.class,i);
		}
		public TerminalNode IN() { return getToken(CoolParser.IN, 0); }
		public TerminalNode INT_CONST() { return getToken(CoolParser.INT_CONST, 0); }
		public TerminalNode STR_CONST() { return getToken(CoolParser.STR_CONST, 0); }
		public TerminalNode BOOL_CONST() { return getToken(CoolParser.BOOL_CONST, 0); }
		public TerminalNode STAR() { return getToken(CoolParser.STAR, 0); }
		public TerminalNode SLASH() { return getToken(CoolParser.SLASH, 0); }
		public TerminalNode PLUS() { return getToken(CoolParser.PLUS, 0); }
		public TerminalNode MINUS() { return getToken(CoolParser.MINUS, 0); }
		public TerminalNode EQ() { return getToken(CoolParser.EQ, 0); }
		public TerminalNode LT() { return getToken(CoolParser.LT, 0); }
		public TerminalNode LE() { return getToken(CoolParser.LE, 0); }
		public TerminalNode DOT() { return getToken(CoolParser.DOT, 0); }
		public TerminalNode AT() { return getToken(CoolParser.AT, 0); }
		public ExprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_expr; }
	}

	public final ExprContext expr() throws RecognitionException {
		return expr(0);
	}

	private ExprContext expr(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		ExprContext _localctx = new ExprContext(_ctx, _parentState);
		ExprContext _prevctx = _localctx;
		int _startState = 10;
		enterRecursionRule(_localctx, 10, RULE_expr, _p);
		int _la;
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(156);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,12,_ctx) ) {
			case 1:
				{
				setState(72);
				match(OBJECTID);
				setState(73);
				match(OPAREN);
				setState(82);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & 141792112558100L) != 0)) {
					{
					setState(74);
					expr(0);
					setState(79);
					_errHandler.sync(this);
					_la = _input.LA(1);
					while (_la==COMMA) {
						{
						{
						setState(75);
						match(COMMA);
						setState(76);
						expr(0);
						}
						}
						setState(81);
						_errHandler.sync(this);
						_la = _input.LA(1);
					}
					}
				}

				setState(84);
				match(CPAREN);
				}
				break;
			case 2:
				{
				setState(85);
				match(IF);
				setState(86);
				expr(0);
				setState(87);
				match(THEN);
				setState(88);
				expr(0);
				setState(89);
				match(ELSE);
				setState(90);
				expr(0);
				setState(91);
				match(FI);
				}
				break;
			case 3:
				{
				setState(93);
				match(WHILE);
				setState(94);
				expr(0);
				setState(95);
				match(LOOP);
				setState(96);
				expr(0);
				setState(97);
				match(POOL);
				}
				break;
			case 4:
				{
				setState(99);
				match(OCURLY);
				setState(103); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(100);
					expr(0);
					setState(101);
					match(SEMI);
					}
					}
					setState(105); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & 141792112558100L) != 0) );
				setState(107);
				match(CCURLY);
				}
				break;
			case 5:
				{
				setState(109);
				match(CASE);
				setState(110);
				expr(0);
				setState(111);
				match(OF);
				setState(119); 
				_errHandler.sync(this);
				_la = _input.LA(1);
				do {
					{
					{
					setState(112);
					match(OBJECTID);
					setState(113);
					match(COLON);
					setState(114);
					match(TYPEID);
					setState(115);
					match(DARROW);
					setState(116);
					expr(0);
					setState(117);
					match(SEMI);
					}
					}
					setState(121); 
					_errHandler.sync(this);
					_la = _input.LA(1);
				} while ( _la==OBJECTID );
				setState(123);
				match(ESAC);
				}
				break;
			case 6:
				{
				setState(125);
				match(NEW);
				setState(126);
				match(TYPEID);
				}
				break;
			case 7:
				{
				setState(127);
				match(OPAREN);
				setState(128);
				expr(0);
				setState(129);
				match(CPAREN);
				}
				break;
			case 8:
				{
				setState(131);
				match(TILDE);
				setState(132);
				expr(12);
				}
				break;
			case 9:
				{
				setState(133);
				match(ISVOID);
				setState(134);
				expr(11);
				}
				break;
			case 10:
				{
				setState(135);
				match(NOT);
				setState(136);
				expr(7);
				}
				break;
			case 11:
				{
				setState(137);
				match(OBJECTID);
				setState(138);
				match(ASSIGN);
				setState(139);
				expr(6);
				}
				break;
			case 12:
				{
				setState(140);
				match(LET);
				setState(141);
				vardecl();
				setState(146);
				_errHandler.sync(this);
				_la = _input.LA(1);
				while (_la==COMMA) {
					{
					{
					setState(142);
					match(COMMA);
					setState(143);
					vardecl();
					}
					}
					setState(148);
					_errHandler.sync(this);
					_la = _input.LA(1);
				}
				setState(149);
				match(IN);
				setState(150);
				expr(5);
				}
				break;
			case 13:
				{
				setState(152);
				match(OBJECTID);
				}
				break;
			case 14:
				{
				setState(153);
				match(INT_CONST);
				}
				break;
			case 15:
				{
				setState(154);
				match(STR_CONST);
				}
				break;
			case 16:
				{
				setState(155);
				match(BOOL_CONST);
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(188);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,17,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(186);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,16,_ctx) ) {
					case 1:
						{
						_localctx = new ExprContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(158);
						if (!(precpred(_ctx, 10))) throw new FailedPredicateException(this, "precpred(_ctx, 10)");
						setState(159);
						_la = _input.LA(1);
						if ( !(_la==STAR || _la==SLASH) ) {
						_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(160);
						expr(11);
						}
						break;
					case 2:
						{
						_localctx = new ExprContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(161);
						if (!(precpred(_ctx, 9))) throw new FailedPredicateException(this, "precpred(_ctx, 9)");
						setState(162);
						_la = _input.LA(1);
						if ( !(_la==PLUS || _la==MINUS) ) {
						_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(163);
						expr(10);
						}
						break;
					case 3:
						{
						_localctx = new ExprContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(164);
						if (!(precpred(_ctx, 8))) throw new FailedPredicateException(this, "precpred(_ctx, 8)");
						setState(165);
						_la = _input.LA(1);
						if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & 622592L) != 0)) ) {
						_errHandler.recoverInline(this);
						}
						else {
							if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
							_errHandler.reportMatch(this);
							consume();
						}
						setState(166);
						expr(9);
						}
						break;
					case 4:
						{
						_localctx = new ExprContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_expr);
						setState(167);
						if (!(precpred(_ctx, 20))) throw new FailedPredicateException(this, "precpred(_ctx, 20)");
						setState(170);
						_errHandler.sync(this);
						_la = _input.LA(1);
						if (_la==AT) {
							{
							setState(168);
							match(AT);
							setState(169);
							match(TYPEID);
							}
						}

						setState(172);
						match(DOT);
						setState(173);
						match(OBJECTID);
						setState(174);
						match(OPAREN);
						setState(183);
						_errHandler.sync(this);
						_la = _input.LA(1);
						if ((((_la) & ~0x3f) == 0 && ((1L << _la) & 141792112558100L) != 0)) {
							{
							setState(175);
							expr(0);
							setState(180);
							_errHandler.sync(this);
							_la = _input.LA(1);
							while (_la==COMMA) {
								{
								{
								setState(176);
								match(COMMA);
								setState(177);
								expr(0);
								}
								}
								setState(182);
								_errHandler.sync(this);
								_la = _input.LA(1);
							}
							}
						}

						setState(185);
						match(CPAREN);
						}
						break;
					}
					} 
				}
				setState(190);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,17,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	@SuppressWarnings("CheckReturnValue")
	public static class VardeclContext extends ParserRuleContext {
		public TerminalNode OBJECTID() { return getToken(CoolParser.OBJECTID, 0); }
		public TerminalNode COLON() { return getToken(CoolParser.COLON, 0); }
		public TerminalNode TYPEID() { return getToken(CoolParser.TYPEID, 0); }
		public TerminalNode ASSIGN() { return getToken(CoolParser.ASSIGN, 0); }
		public ExprContext expr() {
			return getRuleContext(ExprContext.class,0);
		}
		public VardeclContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_vardecl; }
	}

	public final VardeclContext vardecl() throws RecognitionException {
		VardeclContext _localctx = new VardeclContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_vardecl);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(191);
			match(OBJECTID);
			setState(192);
			match(COLON);
			setState(193);
			match(TYPEID);
			setState(196);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==ASSIGN) {
				{
				setState(194);
				match(ASSIGN);
				setState(195);
				expr(0);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 5:
			return expr_sempred((ExprContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean expr_sempred(ExprContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 10);
		case 1:
			return precpred(_ctx, 9);
		case 2:
			return precpred(_ctx, 8);
		case 3:
			return precpred(_ctx, 20);
		}
		return true;
	}

	public static final String _serializedATN =
		"\u0004\u0001D\u00c7\u0002\u0000\u0007\u0000\u0002\u0001\u0007\u0001\u0002"+
		"\u0002\u0007\u0002\u0002\u0003\u0007\u0003\u0002\u0004\u0007\u0004\u0002"+
		"\u0005\u0007\u0005\u0002\u0006\u0007\u0006\u0001\u0000\u0001\u0000\u0001"+
		"\u0000\u0004\u0000\u0012\b\u0000\u000b\u0000\f\u0000\u0013\u0001\u0001"+
		"\u0001\u0001\u0001\u0001\u0001\u0001\u0003\u0001\u001a\b\u0001\u0001\u0001"+
		"\u0001\u0001\u0001\u0001\u0003\u0001\u001f\b\u0001\u0001\u0001\u0001\u0001"+
		"\u0005\u0001#\b\u0001\n\u0001\f\u0001&\t\u0001\u0001\u0001\u0001\u0001"+
		"\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0005\u0002"+
		"/\b\u0002\n\u0002\f\u00022\t\u0002\u0003\u00024\b\u0002\u0001\u0002\u0001"+
		"\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001\u0002\u0001"+
		"\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0001\u0003\u0003\u0003B\b"+
		"\u0003\u0001\u0004\u0001\u0004\u0001\u0004\u0001\u0004\u0001\u0005\u0001"+
		"\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0005\u0005N\b"+
		"\u0005\n\u0005\f\u0005Q\t\u0005\u0003\u0005S\b\u0005\u0001\u0005\u0001"+
		"\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001"+
		"\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001"+
		"\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0004"+
		"\u0005h\b\u0005\u000b\u0005\f\u0005i\u0001\u0005\u0001\u0005\u0001\u0005"+
		"\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005"+
		"\u0001\u0005\u0001\u0005\u0001\u0005\u0004\u0005x\b\u0005\u000b\u0005"+
		"\f\u0005y\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005"+
		"\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005"+
		"\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005"+
		"\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0005\u0005\u0091\b\u0005"+
		"\n\u0005\f\u0005\u0094\t\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001"+
		"\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0003\u0005\u009d\b\u0005\u0001"+
		"\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001"+
		"\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0003"+
		"\u0005\u00ab\b\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001\u0005\u0001"+
		"\u0005\u0001\u0005\u0005\u0005\u00b3\b\u0005\n\u0005\f\u0005\u00b6\t\u0005"+
		"\u0003\u0005\u00b8\b\u0005\u0001\u0005\u0005\u0005\u00bb\b\u0005\n\u0005"+
		"\f\u0005\u00be\t\u0005\u0001\u0006\u0001\u0006\u0001\u0006\u0001\u0006"+
		"\u0001\u0006\u0003\u0006\u00c5\b\u0006\u0001\u0006\u0000\u0001\n\u0007"+
		"\u0000\u0002\u0004\u0006\b\n\f\u0000\u0003\u0001\u0000\f\r\u0001\u0000"+
		"\n\u000b\u0002\u0000\u000f\u0010\u0013\u0013\u00e2\u0000\u0011\u0001\u0000"+
		"\u0000\u0000\u0002\u0015\u0001\u0000\u0000\u0000\u0004)\u0001\u0000\u0000"+
		"\u0000\u0006<\u0001\u0000\u0000\u0000\bC\u0001\u0000\u0000\u0000\n\u009c"+
		"\u0001\u0000\u0000\u0000\f\u00bf\u0001\u0000\u0000\u0000\u000e\u000f\u0003"+
		"\u0002\u0001\u0000\u000f\u0010\u0005\u0001\u0000\u0000\u0010\u0012\u0001"+
		"\u0000\u0000\u0000\u0011\u000e\u0001\u0000\u0000\u0000\u0012\u0013\u0001"+
		"\u0000\u0000\u0000\u0013\u0011\u0001\u0000\u0000\u0000\u0013\u0014\u0001"+
		"\u0000\u0000\u0000\u0014\u0001\u0001\u0000\u0000\u0000\u0015\u0016\u0005"+
		"\u0014\u0000\u0000\u0016\u0019\u0005(\u0000\u0000\u0017\u0018\u0005\u0019"+
		"\u0000\u0000\u0018\u001a\u0005(\u0000\u0000\u0019\u0017\u0001\u0000\u0000"+
		"\u0000\u0019\u001a\u0001\u0000\u0000\u0000\u001a\u001b\u0001\u0000\u0000"+
		"\u0000\u001b$\u0005\u0002\u0000\u0000\u001c\u001f\u0003\u0004\u0002\u0000"+
		"\u001d\u001f\u0003\u0006\u0003\u0000\u001e\u001c\u0001\u0000\u0000\u0000"+
		"\u001e\u001d\u0001\u0000\u0000\u0000\u001f \u0001\u0000\u0000\u0000 !"+
		"\u0005\u0001\u0000\u0000!#\u0001\u0000\u0000\u0000\"\u001e\u0001\u0000"+
		"\u0000\u0000#&\u0001\u0000\u0000\u0000$\"\u0001\u0000\u0000\u0000$%\u0001"+
		"\u0000\u0000\u0000%\'\u0001\u0000\u0000\u0000&$\u0001\u0000\u0000\u0000"+
		"\'(\u0005\u0003\u0000\u0000(\u0003\u0001\u0000\u0000\u0000)*\u0005\'\u0000"+
		"\u0000*3\u0005\u0004\u0000\u0000+0\u0003\b\u0004\u0000,-\u0005\u0005\u0000"+
		"\u0000-/\u0003\b\u0004\u0000.,\u0001\u0000\u0000\u0000/2\u0001\u0000\u0000"+
		"\u00000.\u0001\u0000\u0000\u000001\u0001\u0000\u0000\u000014\u0001\u0000"+
		"\u0000\u000020\u0001\u0000\u0000\u00003+\u0001\u0000\u0000\u000034\u0001"+
		"\u0000\u0000\u000045\u0001\u0000\u0000\u000056\u0005\u0006\u0000\u0000"+
		"67\u0005\u0007\u0000\u000078\u0005(\u0000\u000089\u0005\u0002\u0000\u0000"+
		"9:\u0003\n\u0005\u0000:;\u0005\u0003\u0000\u0000;\u0005\u0001\u0000\u0000"+
		"\u0000<=\u0005\'\u0000\u0000=>\u0005\u0007\u0000\u0000>A\u0005(\u0000"+
		"\u0000?@\u0005\u0012\u0000\u0000@B\u0003\n\u0005\u0000A?\u0001\u0000\u0000"+
		"\u0000AB\u0001\u0000\u0000\u0000B\u0007\u0001\u0000\u0000\u0000CD\u0005"+
		"\'\u0000\u0000DE\u0005\u0007\u0000\u0000EF\u0005(\u0000\u0000F\t\u0001"+
		"\u0000\u0000\u0000GH\u0006\u0005\uffff\uffff\u0000HI\u0005\'\u0000\u0000"+
		"IR\u0005\u0004\u0000\u0000JO\u0003\n\u0005\u0000KL\u0005\u0005\u0000\u0000"+
		"LN\u0003\n\u0005\u0000MK\u0001\u0000\u0000\u0000NQ\u0001\u0000\u0000\u0000"+
		"OM\u0001\u0000\u0000\u0000OP\u0001\u0000\u0000\u0000PS\u0001\u0000\u0000"+
		"\u0000QO\u0001\u0000\u0000\u0000RJ\u0001\u0000\u0000\u0000RS\u0001\u0000"+
		"\u0000\u0000ST\u0001\u0000\u0000\u0000T\u009d\u0005\u0006\u0000\u0000"+
		"UV\u0005\u0017\u0000\u0000VW\u0003\n\u0005\u0000WX\u0005\u001e\u0000\u0000"+
		"XY\u0003\n\u0005\u0000YZ\u0005\u0015\u0000\u0000Z[\u0003\n\u0005\u0000"+
		"[\\\u0005\u0016\u0000\u0000\\\u009d\u0001\u0000\u0000\u0000]^\u0005\u001f"+
		"\u0000\u0000^_\u0003\n\u0005\u0000_`\u0005\u001c\u0000\u0000`a\u0003\n"+
		"\u0005\u0000ab\u0005\u001d\u0000\u0000b\u009d\u0001\u0000\u0000\u0000"+
		"cg\u0005\u0002\u0000\u0000de\u0003\n\u0005\u0000ef\u0005\u0001\u0000\u0000"+
		"fh\u0001\u0000\u0000\u0000gd\u0001\u0000\u0000\u0000hi\u0001\u0000\u0000"+
		"\u0000ig\u0001\u0000\u0000\u0000ij\u0001\u0000\u0000\u0000jk\u0001\u0000"+
		"\u0000\u0000kl\u0005\u0003\u0000\u0000l\u009d\u0001\u0000\u0000\u0000"+
		"mn\u0005 \u0000\u0000no\u0003\n\u0005\u0000ow\u0005#\u0000\u0000pq\u0005"+
		"\'\u0000\u0000qr\u0005\u0007\u0000\u0000rs\u0005(\u0000\u0000st\u0005"+
		"\u0011\u0000\u0000tu\u0003\n\u0005\u0000uv\u0005\u0001\u0000\u0000vx\u0001"+
		"\u0000\u0000\u0000wp\u0001\u0000\u0000\u0000xy\u0001\u0000\u0000\u0000"+
		"yw\u0001\u0000\u0000\u0000yz\u0001\u0000\u0000\u0000z{\u0001\u0000\u0000"+
		"\u0000{|\u0005!\u0000\u0000|\u009d\u0001\u0000\u0000\u0000}~\u0005\"\u0000"+
		"\u0000~\u009d\u0005(\u0000\u0000\u007f\u0080\u0005\u0004\u0000\u0000\u0080"+
		"\u0081\u0003\n\u0005\u0000\u0081\u0082\u0005\u0006\u0000\u0000\u0082\u009d"+
		"\u0001\u0000\u0000\u0000\u0083\u0084\u0005\u000e\u0000\u0000\u0084\u009d"+
		"\u0003\n\u0005\f\u0085\u0086\u0005\u001a\u0000\u0000\u0086\u009d\u0003"+
		"\n\u0005\u000b\u0087\u0088\u0005$\u0000\u0000\u0088\u009d\u0003\n\u0005"+
		"\u0007\u0089\u008a\u0005\'\u0000\u0000\u008a\u008b\u0005\u0012\u0000\u0000"+
		"\u008b\u009d\u0003\n\u0005\u0006\u008c\u008d\u0005\u001b\u0000\u0000\u008d"+
		"\u0092\u0003\f\u0006\u0000\u008e\u008f\u0005\u0005\u0000\u0000\u008f\u0091"+
		"\u0003\f\u0006\u0000\u0090\u008e\u0001\u0000\u0000\u0000\u0091\u0094\u0001"+
		"\u0000\u0000\u0000\u0092\u0090\u0001\u0000\u0000\u0000\u0092\u0093\u0001"+
		"\u0000\u0000\u0000\u0093\u0095\u0001\u0000\u0000\u0000\u0094\u0092\u0001"+
		"\u0000\u0000\u0000\u0095\u0096\u0005\u0018\u0000\u0000\u0096\u0097\u0003"+
		"\n\u0005\u0005\u0097\u009d\u0001\u0000\u0000\u0000\u0098\u009d\u0005\'"+
		"\u0000\u0000\u0099\u009d\u0005&\u0000\u0000\u009a\u009d\u0005/\u0000\u0000"+
		"\u009b\u009d\u0005%\u0000\u0000\u009cG\u0001\u0000\u0000\u0000\u009cU"+
		"\u0001\u0000\u0000\u0000\u009c]\u0001\u0000\u0000\u0000\u009cc\u0001\u0000"+
		"\u0000\u0000\u009cm\u0001\u0000\u0000\u0000\u009c}\u0001\u0000\u0000\u0000"+
		"\u009c\u007f\u0001\u0000\u0000\u0000\u009c\u0083\u0001\u0000\u0000\u0000"+
		"\u009c\u0085\u0001\u0000\u0000\u0000\u009c\u0087\u0001\u0000\u0000\u0000"+
		"\u009c\u0089\u0001\u0000\u0000\u0000\u009c\u008c\u0001\u0000\u0000\u0000"+
		"\u009c\u0098\u0001\u0000\u0000\u0000\u009c\u0099\u0001\u0000\u0000\u0000"+
		"\u009c\u009a\u0001\u0000\u0000\u0000\u009c\u009b\u0001\u0000\u0000\u0000"+
		"\u009d\u00bc\u0001\u0000\u0000\u0000\u009e\u009f\n\n\u0000\u0000\u009f"+
		"\u00a0\u0007\u0000\u0000\u0000\u00a0\u00bb\u0003\n\u0005\u000b\u00a1\u00a2"+
		"\n\t\u0000\u0000\u00a2\u00a3\u0007\u0001\u0000\u0000\u00a3\u00bb\u0003"+
		"\n\u0005\n\u00a4\u00a5\n\b\u0000\u0000\u00a5\u00a6\u0007\u0002\u0000\u0000"+
		"\u00a6\u00bb\u0003\n\u0005\t\u00a7\u00aa\n\u0014\u0000\u0000\u00a8\u00a9"+
		"\u0005\b\u0000\u0000\u00a9\u00ab\u0005(\u0000\u0000\u00aa\u00a8\u0001"+
		"\u0000\u0000\u0000\u00aa\u00ab\u0001\u0000\u0000\u0000\u00ab\u00ac\u0001"+
		"\u0000\u0000\u0000\u00ac\u00ad\u0005\t\u0000\u0000\u00ad\u00ae\u0005\'"+
		"\u0000\u0000\u00ae\u00b7\u0005\u0004\u0000\u0000\u00af\u00b4\u0003\n\u0005"+
		"\u0000\u00b0\u00b1\u0005\u0005\u0000\u0000\u00b1\u00b3\u0003\n\u0005\u0000"+
		"\u00b2\u00b0\u0001\u0000\u0000\u0000\u00b3\u00b6\u0001\u0000\u0000\u0000"+
		"\u00b4\u00b2\u0001\u0000\u0000\u0000\u00b4\u00b5\u0001\u0000\u0000\u0000"+
		"\u00b5\u00b8\u0001\u0000\u0000\u0000\u00b6\u00b4\u0001\u0000\u0000\u0000"+
		"\u00b7\u00af\u0001\u0000\u0000\u0000\u00b7\u00b8\u0001\u0000\u0000\u0000"+
		"\u00b8\u00b9\u0001\u0000\u0000\u0000\u00b9\u00bb\u0005\u0006\u0000\u0000"+
		"\u00ba\u009e\u0001\u0000\u0000\u0000\u00ba\u00a1\u0001\u0000\u0000\u0000"+
		"\u00ba\u00a4\u0001\u0000\u0000\u0000\u00ba\u00a7\u0001\u0000\u0000\u0000"+
		"\u00bb\u00be\u0001\u0000\u0000\u0000\u00bc\u00ba\u0001\u0000\u0000\u0000"+
		"\u00bc\u00bd\u0001\u0000\u0000\u0000\u00bd\u000b\u0001\u0000\u0000\u0000"+
		"\u00be\u00bc\u0001\u0000\u0000\u0000\u00bf\u00c0\u0005\'\u0000\u0000\u00c0"+
		"\u00c1\u0005\u0007\u0000\u0000\u00c1\u00c4\u0005(\u0000\u0000\u00c2\u00c3"+
		"\u0005\u0012\u0000\u0000\u00c3\u00c5\u0003\n\u0005\u0000\u00c4\u00c2\u0001"+
		"\u0000\u0000\u0000\u00c4\u00c5\u0001\u0000\u0000\u0000\u00c5\r\u0001\u0000"+
		"\u0000\u0000\u0013\u0013\u0019\u001e$03AORiy\u0092\u009c\u00aa\u00b4\u00b7"+
		"\u00ba\u00bc\u00c4";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}