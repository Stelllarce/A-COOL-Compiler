#!/usr/bin/env bash
pushd tools
unzip -p check it | bash --noprofile --norc "$@"
popd
